var stage = new Konva.Stage({
    container: 'container',
    width: 210 * 3.78, // Conversion to pixels
    height: 297 * 3.78 // Conversion to pixels
});

var layer = new Konva.Layer();
stage.add(layer);
function addText() {
// Configuración predeterminada del texto
var defaultTextConfig = {
    text: 'Nuevo texto',             // Texto inicial
    x: 10,                           // Posición x del texto (margen de 10px)
    y: 10,                           // Posición y del texto (margen de 10px)
    fontSize: 20,                    // Tamaño de la fuente
    fontFamily: 'Arial',             // Familia de la fuente
    fill: 'black',                   // Color del texto
    draggable: true,                 // Hacer que el texto sea arrastrable
    fontStyle: 'normal',             // Estilo de fuente normal
    padding: 5,                      // Relleno alrededor del texto
    align: 'left',                   // Alineación del texto
    verticalAlign: 'top',            // Alineación vertical del texto
    wrap: 'word',                    // Envolver texto por palabras
    width: 210 * 3.7795275591 - 20,  // Ancho del área de texto (A4 en mm a px, menos margen)
    height: 297 * 3.7795275591 - 20  // Altura del área de texto (A4 en mm a px, menos margen)
};

// Crear una nueva instancia de Konva.Text con la configuración predeterminada
var textNode = new Konva.Text(defaultTextConfig);

// Añadir el nodo de texto a la capa y dibujarlo
layer.add(textNode);
layer.draw();

// Función para crear y estilizar el área de texto para edición
function createTextarea() {
    var textarea = document.createElement('textarea'); // Crear un elemento textarea
    document.body.appendChild(textarea);               // Añadir el textarea al cuerpo del documento

    // Configurar las propiedades y estilo del textarea
    textarea.value = textNode.text();                  // Establecer el valor del textarea con el texto del nodo
    textarea.style.position = 'absolute';              // Posicionar el textarea de forma absoluta
    textarea.style.top = textNode.getClientRect().y + 'px'; // Posición vertical del textarea
    textarea.style.left = textNode.getClientRect().x + 'px'; // Posición horizontal del textarea
    textarea.style.width = textNode.width() - textNode.padding() * 2 + 'px'; // Ancho del textarea
    textarea.style.height = textNode.height() - textNode.padding() * 2 + 'px'; // Altura del textarea
    textarea.style.fontSize = textNode.fontSize() + 'px'; // Tamaño de la fuente
    textarea.style.fontFamily = textNode.fontFamily();  // Familia de la fuente
    textarea.style.color = textNode.fill();             // Color del texto
    textarea.style.background = 'none';                 // Fondo transparente
    textarea.style.border = 'none';                     // Sin borde
    textarea.style.padding = '0px';                     // Sin relleno
    textarea.style.margin = '0px';                      // Sin margen
    textarea.style.overflow = 'hidden';                 // Sin desbordamiento
    textarea.style.outline = 'none';                    // Sin contorno
    textarea.style.resize = 'none';                     // No redimensionable
    textarea.style.lineHeight = textNode.lineHeight();  // Altura de línea
    textarea.style.transformOrigin = 'left top';        // Origen de la transformación
    textarea.style.textAlign = textNode.align();        // Alineación del texto
    textarea.style.whiteSpace = 'pre-wrap';             // Espacio en blanco
    textarea.style.wordBreak = 'break-word';            // Romper palabras
    textarea.style.fontStyle = textNode.fontStyle();    // Estilo de la fuente
    textarea.style.transform = 'rotate(' + textNode.rotation() + 'deg)'; // Rotación del textarea
    textarea.focus();                                   // Focalizar el textarea

    return textarea;                                    // Devolver el textarea
}

// Manejar doble clic para editar el texto
textNode.on('dblclick', () => {
    var textarea = createTextarea(); // Crear y estilizar el textarea

    // Agregar evento para manejar la tecla Enter en el textarea
    textarea.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {      // Si se presiona la tecla Enter
            textNode.text(textarea.value); // Actualizar el texto del nodo
            document.body.removeChild(textarea); // Eliminar el textarea
            layer.draw();             // Redibujar la capa
        }
    });

    // Agregar evento para manejar la pérdida de enfoque del textarea
    textarea.addEventListener('blur', function () {
        textNode.text(textarea.value); // Actualizar el texto del nodo
        document.body.removeChild(textarea); // Eliminar el textarea
        layer.draw();                 // Redibujar la capa
    });
});

// Manejar clic para alternar el estilo de fuente entre normal y negrita
textNode.on('click', () => {
    textNode.fontStyle(textNode.fontStyle() === 'bold' ? 'normal' : 'bold'); // Alternar estilo de fuente
    layer.draw();                     // Redibujar la capa
});

// Añadir un menú contextual para cambiar las propiedades del texto
textNode.on('contextmenu', (e) => {
    e.evt.preventDefault();           // Prevenir el menú contextual predeterminado

    // Crear un menú contextual con opciones para la familia de fuentes, tamaño y color
    var menu = document.createElement('div');
    menu.style.position = 'absolute';
    menu.style.top = e.evt.clientY + 'px';
    menu.style.left = e.evt.clientX + 'px';
    menu.style.backgroundColor = 'white';
    menu.style.border = '1px solid #ccc';
    menu.style.padding = '10px';
    menu.style.zIndex = 10000;

    // Input para la familia de fuentes
    var fontFamilyInput = document.createElement('input');
    fontFamilyInput.type = 'text';
    fontFamilyInput.value = textNode.fontFamily();
    fontFamilyInput.placeholder = 'Font Family';
    menu.appendChild(fontFamilyInput);

    // Input para el tamaño de la fuente
    var fontSizeInput = document.createElement('input');
    fontSizeInput.type = 'number';
    fontSizeInput.value = textNode.fontSize();
    fontSizeInput.placeholder = 'Font Size';
    menu.appendChild(fontSizeInput);

    // Input para el color de la fuente
    var fontColorInput = document.createElement('input');
    fontColorInput.type = 'color';
    fontColorInput.value = textNode.fill();
    menu.appendChild(fontColorInput);

    // Botón para aplicar los cambios
    var applyButton = document.createElement('button');
    applyButton.textContent = 'Aplicar';
    menu.appendChild(applyButton);

    // Agregar evento al botón aplicar para actualizar las propiedades del texto
    applyButton.addEventListener('click', () => {
        textNode.fontFamily(fontFamilyInput.value);    // Actualizar la familia de fuentes
        textNode.fontSize(Number(fontSizeInput.value)); // Actualizar el tamaño de la fuente
        textNode.fill(fontColorInput.value);           // Actualizar el color del texto
        layer.draw();                                  // Redibujar la capa
        document.body.removeChild(menu);               // Eliminar el menú
    });

    // Eliminar el menú si se hace clic fuera de él
    document.addEventListener('click', function onDocumentClick(event) {
        if (!menu.contains(event.target)) {           // Si el clic no está dentro del menú
            document.body.removeChild(menu);           // Eliminar el menú
            document.removeEventListener('click', onDocumentClick); // Eliminar el evento de clic
        }
    });

    document.body.appendChild(menu);                  // Añadir el menú al cuerpo del documento
});
}
    
document.getElementById('addText').addEventListener('click', addText);

document.getElementById('downloadPdf').addEventListener('click', function() {
    var dataURL = stage.toDataURL();
    fetch('save.php', {
        method: 'POST',
        body: JSON.stringify({ imageData: dataURL, type: 'pdf' }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.blob())
      .then(blob => {
          var link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = 'documento.pdf';
          link.click();
      });
});

document.getElementById('downloadJson').addEventListener('click', function() {
    var json = stage.toJSON();
    var blob = new Blob([json], { type: 'application/json' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'documento.json';
    link.click();
});