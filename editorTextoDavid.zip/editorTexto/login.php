
<?php
require 'config.php';
session_start();

// Limpia los datos del formulario
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Función para verificar las credenciales del usuario
function verifyUser($conn, $username, $password) {
    try {
        // Prepara la declaración SQL para evitar inyecciones SQL
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica la contraseña
        if ($user && password_verify($password, $user['password'])) {
            return $user['id'];
        } else {
            return false;
        }
    } catch (PDOException $e) {
        // Registra cualquier error de la base de datos
        error_log("Error: " . $e->getMessage());
        return false;
    }
}

// Verifica si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Limpia la entrada del usuario
    $username = sanitizeInput($_POST['username']);
    $password = sanitizeInput($_POST['password']);

    // Verifica las credenciales del usuario
    $userId = verifyUser($conn, $username, $password);

    if ($userId) {
        // Guarda el ID del usuario en la sesión y redirige a la página principal
        $_SESSION['user_id'] = $userId;
        header("Location: index.php");
        exit;
    } else {
        // mensaje de error
        $error = "Nombre de usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Acceso</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <form method="post" action="login.php">
        <label>Usuario:</label>
        <input type="text" name="username" required>
        <br>
        <label>Contraseña:</label>
        <input type="password" name="password" required>
        <br>
        <input type="submit" value="Acceder">
        
    </form>
    <a href="register.php">Registrarse</a>
    <?php if (!empty($error)) : ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
</body>
</html>
