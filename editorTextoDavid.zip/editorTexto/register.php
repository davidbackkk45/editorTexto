<?php
require 'config.php';

// Función para sanitizar la entrada del usuario
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Función para registrar un nuevo usuario
function registerUser($conn, $username, $email, $password, $name) {
    try {
        // Preparar la declaración SQL para prevenir la inyección SQL
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, name) VALUES (:username, :email, :password, :name)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':name', $name);

        // Ejecutar la declaración y devolver el resultado
        return $stmt->execute();
    } catch (PDOException $e) {
        // Registrar cualquier error de la base de datos
        error_log("Error: " . $e->getMessage());
        return false;
    }
}

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitizar y recuperar las entradas del usuario
    $username = sanitizeInput($_POST['username']);
    $email = sanitizeInput($_POST['email']);
    $password = password_hash(sanitizeInput($_POST['password']), PASSWORD_BCRYPT);
    $name = sanitizeInput($_POST['name']);

    // Registrar el nuevo usuario
    if (registerUser($conn, $username, $email, $password, $name)) {
        // Redirigir a la página de inicio de sesión tras un registro exitoso
        header("Location: login.php");
        exit;
    } else {
        // Establecer un mensaje de error si el registro falla
        $error = "Error: No se pudo registrar el usuario.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- Formulario de registro -->
    <form method="post" action="register.php">
        <label>Usuario:</label>
        <input type="text" name="username" required>
        <br>
        <label>Correo:</label>
        <input type="email" name="email" required>
        <br>
        <label>Contraseña:</label>
        <input type="password" name="password" required>
        <br>
        <label>Nombre:</label>
        <input type="text" name="name" required>
        <br>
        <input type="submit" value="Registrarse">
    </form>
    <a href="login.php">Iniciar sesión</a>
    <!-- Mostrar mensaje de error si existe alguno -->
    <?php if (!empty($error)) : ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
</body>
</html>
