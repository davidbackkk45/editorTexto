<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Página Principal</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/konva@8.3.6/konva.min.js"></script>
</head>
<body>
    <h1>Editor de Folios</h1>
    <ul>
        <li><a href="manage_users.php">Gestión de Usuarios</a></li>
    </ul>
    <div class="editor-controls">
        <button id="addText">Añadir Texto</button>
        <button id="downloadPdf">Descargar PDF</button>
        <button id="downloadJson">Descargar JSON</button>
    </div>
    <div id="container"></div>
    <a href="logout.php">Cerrar Sesión</a>

    <script src="https://cdn.jsdelivr.net/npm/konva@8.3.6/konva.min.js"></script>
    <script src="js/editor.js"></script>
</body>
</html>
