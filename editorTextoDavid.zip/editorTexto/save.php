<?php
require 'config.php';
require 'fpdf/fpdf.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Iniciar el almacenamiento en búfer de salida
ob_start();

// Obtener los datos enviados desde el frontend
$data = json_decode(file_get_contents('php://input'), true);

if ($data['type'] == 'pdf') {
    // Obtener la imagen en base64 y decodificarla
    $imageData = $data['imageData'];
    $imageData = str_replace('data:image/png;base64,', '', $imageData);
    $imageData = base64_decode($imageData);

    // Crear un nuevo PDF
    $pdf = new FPDF();
    $pdf->AddPage('P', 'A4');

    // Guardar la imagen temporalmente
    $imagePath = tempnam(sys_get_temp_dir(), 'image_') . '.png';
    file_put_contents($imagePath, $imageData);

    // Añadir la imagen al PDF
    $pdf->Image($imagePath, 0, 0, 210, 297);

    // Eliminar la imagen temporal
    unlink($imagePath);

    // Limpiar el búfer de salida
    ob_end_clean();

    // Enviar el PDF como respuesta
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="document.pdf"');
    $pdf->Output('F', 'document.pdf');

    // Enviar el PDF generado
    readfile('document.pdf');
    unlink('document.pdf');
    exit;
}
?>
