<?php
require 'config.php';
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Función para redirigir con mensaje de error
function redirectWithError($location, $message) {
    $_SESSION['error'] = $message;
    header("Location: $location");
    exit;
}

// Manejo de eliminación de usuarios
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id']; // Asegurar que sea un entero
    $stmt = $conn->prepare("DELETE FROM users WHERE id = :id");
    $stmt->bindParam(':id', $delete_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        header("Location: manage_users.php");
    } else {
        redirectWithError('manage_users.php', 'Error al eliminar el usuario.');
    }
    exit;
}

// Manejo de actualización de usuarios
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
    $update_id = (int)$_POST['update_id']; // Asegurar que sea un entero
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $name = trim($_POST['name']);

    // Validar campos
    if (empty($username) || empty($email) || empty($name)) {
        redirectWithError('manage_users.php?edit_id=' . $update_id, 'Todos los campos son obligatorios.');
    }

    // Si se proporciona una nueva contraseña, actualizarla
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email, name = :name, password = :password WHERE id = :id");
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
    } else {
        $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email, name = :name WHERE id = :id");
    }

    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':id', $update_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: manage_users.php");
    } else {
        redirectWithError('manage_users.php?edit_id=' . $update_id, 'Error al actualizar el usuario.');
    }
    exit;
}

// Preparar y ejecutar la consulta para obtener la lista de usuarios
$stmt = $conn->prepare("SELECT id, username, email, name, created_at FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h1>Gestión de Usuarios</h1>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Correo</th>
            <th>Nombre</th>
            <th>Fecha de Creación</th>
            <th>Acciones</th>
        </tr>
        <!-- Mostrar la lista de usuarios en una tabla -->
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user['id']); ?></td>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo htmlspecialchars($user['name']); ?></td>
            <td><?php echo htmlspecialchars($user['created_at']); ?></td>
            <td>
                <a href="manage_users.php?edit_id=<?php echo htmlspecialchars($user['id']); ?>">Editar</a>
                <a href="manage_users.php?delete_id=<?php echo htmlspecialchars($user['id']); ?>" onclick="return confirm('¿Está seguro de que desea eliminar este usuario?');">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="index.php">Volver a la Página Principal</a>

    <!-- Formulario de actualización de usuario -->
    <?php if (isset($_GET['edit_id'])): ?>
    <?php
    $edit_id = (int)$_GET['edit_id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $edit_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
    <h2>Editar Usuario</h2>
    <form method="post" action="manage_users.php">
        <input type="hidden" name="update_id" value="<?php echo htmlspecialchars($user['id']); ?>">
        <label>Usuario:</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        <br>
        <label>Correo:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        <br>
        <label>Nombre:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
        <br>
        <label>Contraseña (dejar en blanco para no cambiar):</label>
        <input type="password" name="password">
        <br>
        <input type="submit" value="Actualizar">
    </form>
    <?php endif; ?>

    
    <h2>Registrar Nuevo Usuario</h2>
    <form method="post" action="register.php">
        <label>Usuario:</label>
        <input type="text" name="username" required>
        <br>
        <label>Correo:</label>
        <input type="email" name="email" required>
        <br>
        <label>Nombre:</label>
        <input type="text" name="name" required>
        <br>
        <label>Contraseña:</label>
        <input type="password" name="password" required>
        <br>
        <input type="submit" value="Registrar">
    </form>
</body>
</html>
